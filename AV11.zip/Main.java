module AV1 {
	
import java.util.Scanner;
	
	  public static void main(String[] args) {

		  String[] nome = new String[10];
		  int[] nota = new int[10];
		  double soma = 0;
      int aux;
		  double media;

		  for(int i = 0; i < nota.length; ++i){
		      System.out.println("Digite o nome do aluno \n"+(i+1)+"º : ");
		      nome[i] = input.nextLine();
		      System.out.println("Digite a nota do aluno\n"+(i+1)+"º : ");
		      nota[i] = input.nextLine();
		      soma = soma + nota[i];
		  }
		 
		   media = soma/nota.length;
		    
		   for(int i = 0; i < nota.length; i++){
		   for(int j = 0; j<9; j++){
         if(nota[j]>nota[j+1]){
           aux = nota[j];
           nota[j] = nota[j+1];
           nota[j+1] = aux; 
         }
       }
		    }    
		    
		  
	                System.out.println("A maior nota é/n " + nota[9] );
	                
	                System.out.println("A menor nota é/n" + nota[1]);
	                
	                }
		  }     

		  
	
