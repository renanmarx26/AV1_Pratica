module MVP {
	
	public static void main(String[] args) {
	Scanner entrada = new Scanner(System.in);
	
	  int Cadastro , Buscar , Sair ;
	  int Itens, Autor, Local, Data, Descricao;

	  System.out.println ("1 - Cadastrar Item Perdido\n");
	  Cadastro = entrada.nextInt();
	  Buscar = entrada.nextInt();
	  Itens = entrada.nextInt();
	  Autor = entrada.nextInt();
	  Local = entrada.nextInt();
	  Data = entrada.nextInt();
	  Descricao = entrada.nextInt();
	  
	  if
	  {
	  System.out.println ("Gentileza informar: item, autor, local, data e descricao\n");
	  }

	  System.out.println ("2 - Buscar Item\n");
	  Itens = entrada.nextInt();
	  
	  if else {
		  System.out.println("Gentileza informar o item: \n");  
	  }
	  
	  System.out.println ("3 - Sair\n");
	  Cancelar = entrada.nextInt();
	  if else {
		  System.out.println("Total itens cadastrados: \n" + itens );  
	  }
	  
	  

}
}